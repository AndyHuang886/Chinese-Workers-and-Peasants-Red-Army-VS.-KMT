import pygame
import sys
import os
import random
import math

pygame.init()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MAIN_BG_PATH = os.path.join(BASE_DIR, "bg1.png")
LEVEL1_BG_PATH = os.path.join(BASE_DIR, "level1_bg.png")
LEVEL2_BG_PATH = os.path.join(BASE_DIR, "level2_bg.jpg")
LEVEL3_BG_PATH = os.path.join(BASE_DIR, "level3_bg.jpeg")
FONT_PATH = "C:/Windows/Fonts/msyh.ttc"

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("红军大战蒋介石——长征")

WHITE = (255, 255, 255)
BLUE = (0, 120, 215)
LIGHT_BLUE = (50, 150, 255)
RED = (200, 0, 0)
LIGHT_RED = (255, 50, 50)
GREEN = (0, 180, 0)
YELLOW = (255, 215, 0)
ORANGE = (255, 140, 0)
GRAY = (128, 128, 128)
PURPLE = (128, 0, 128)
BROWN = (139, 69, 19)
BG_COLOR = (30, 30, 30)
GRID_COLOR = (255, 255, 255, 80)
HP_BAR_RED = (255, 0, 0)
HP_BAR_GREEN = (0, 255, 0)
OVERLAY_COLOR = (0, 0, 0, 180)

main_bg = None
try:
    main_bg = pygame.image.load(MAIN_BG_PATH).convert()
    main_bg = pygame.transform.scale(main_bg, (SCREEN_WIDTH, SCREEN_HEIGHT))
except:
    print("未读取到主菜单背景图")

level1_bg = None
try:
    level1_bg = pygame.image.load(LEVEL1_BG_PATH).convert()
    bg_ratio = level1_bg.get_width() / level1_bg.get_height()
    target_width = int(SCREEN_HEIGHT * bg_ratio)
    level1_bg = pygame.transform.scale(level1_bg, (target_width, SCREEN_HEIGHT))
    if target_width > SCREEN_WIDTH:
        crop_rect = pygame.Rect((target_width - SCREEN_WIDTH) // 2, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
        level1_bg = level1_bg.subsurface(crop_rect)
except:
    print("未读取到血战湘江地图")

level2_bg = None
try:
    level2_bg = pygame.image.load(LEVEL2_BG_PATH).convert()
    bg_ratio = level2_bg.get_width() / level2_bg.get_height()
    target_width = int(SCREEN_HEIGHT * bg_ratio)
    level2_bg = pygame.transform.scale(level2_bg, (target_width, SCREEN_HEIGHT))
    if target_width > SCREEN_WIDTH:
        crop_rect = pygame.Rect((target_width - SCREEN_WIDTH) // 2, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
        level2_bg = level2_bg.subsurface(crop_rect)
except:
    print("未读取到翻雪山地图")

level3_bg = None
try:
    level3_bg = pygame.image.load(LEVEL3_BG_PATH).convert()
    bg_ratio = level3_bg.get_width() / level3_bg.get_height()
    target_width = int(SCREEN_HEIGHT * bg_ratio)
    level3_bg = pygame.transform.scale(level3_bg, (target_width, SCREEN_HEIGHT))
    if target_width > SCREEN_WIDTH:
        crop_rect = pygame.Rect((target_width - SCREEN_WIDTH) // 2, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
        level3_bg = level3_bg.subsurface(crop_rect)
except:
    print("未读取到过草地地图")

try:
    title_font = pygame.font.Font(FONT_PATH, 100)
    button_font = pygame.font.Font(FONT_PATH, 60)
    small_font = pygame.font.Font(FONT_PATH, 30)
    tiny_font = pygame.font.Font(FONT_PATH, 20)
except:
    title_font = pygame.font.SysFont("Microsoft YaHei", 100)
    button_font = pygame.font.SysFont("Microsoft YaHei", 60)
    small_font = pygame.font.SysFont("Microsoft YaHei", 30)
    tiny_font = pygame.font.SysFont("Microsoft YaHei", 20)

title_text = title_font.render("红军大战蒋介石", True, (255, 165, 25))
title_rect = title_text.get_rect(center=(SCREEN_WIDTH//2, 150))

ROWS = 8
COLS = 9
CELL_WIDTH = 102
CELL_HEIGHT = 71
OFFSET_X = 280
OFFSET_Y = 135

game_state = {
    "resources": 150,
    "score": 0,
    "wave": 1,
    "completed_levels": set()
}

class Bullet:
    def __init__(self, x, y, damage):
        self.x = x
        self.y = y
        self.damage = damage
        self.speed = 8
        self.rect = pygame.Rect(self.x - 5, self.y - 3, 10, 6)

    def update(self):
        self.x += self.speed
        self.rect.x = self.x - 5

    def draw(self, screen):
        pygame.draw.rect(screen, YELLOW, self.rect)

class ArtilleryBullet:
    def __init__(self, x, y, target_x, target_y, damage):
        self.x = x
        self.y = y
        self.damage = damage
        self.start_x = x
        self.start_y = y
        self.target_x = target_x
        self.target_y = target_y
        self.progress = 0
        self.speed = 0.05
        self.rect = pygame.Rect(self.x - 8, self.y - 8, 16, 16)
        self.explosion_timer = 0

    def update(self):
        if self.explosion_timer > 0:
            self.explosion_timer -= 1
            return False
        self.progress += self.speed
        if self.progress >= 1:
            self.explosion_timer = 10
            return False
        self.x = self.start_x + (self.target_x - self.start_x) * self.progress
        arc = -100 * (self.progress - 0.5) ** 2 + 25
        self.y = self.start_y + (self.target_y - self.start_y) * self.progress - arc
        self.rect.x = self.x - 8
        self.rect.y = self.y - 8
        return True

    def draw(self, screen):
        if self.explosion_timer > 0:
            alpha = int(255 * (self.explosion_timer / 10))
            explosion_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
            pygame.draw.circle(explosion_surf, (255, 100, 0, alpha), (30, 30), 28, 3)
            pygame.draw.circle(explosion_surf, (255, 200, 0, alpha), (30, 30), 18, 2)
            screen.blit(explosion_surf, (self.target_x - 30, self.target_y - 30))
        else:
            pygame.draw.circle(screen, ORANGE, (int(self.x), int(self.y)), 8)
            pygame.draw.circle(screen, YELLOW, (int(self.x), int(self.y)), 5)

class Unit:
    def __init__(self, row, col, hp, damage, speed, color, cost, attack_range, attack_interval):
        self.row = row
        self.col = col
        self.hp = hp
        self.max_hp = hp
        self.damage = damage
        self.speed = speed
        self.color = color
        self.cost = cost
        self.attack_range = attack_range
        self.attack_interval = attack_interval
        self.attack_cooldown = 0
        self.attack_animation_timer = 0
        self.attack_animation_duration = 15
        
        self.x = OFFSET_X + col * CELL_WIDTH + CELL_WIDTH // 2
        self.y = OFFSET_Y + row * CELL_HEIGHT + CELL_HEIGHT // 2
        self.rect = pygame.Rect(self.x - 20, self.y - 25, 40, 50)

    def update(self):
        self.attack_cooldown = max(0, self.attack_cooldown - 1)
        self.attack_animation_timer = max(0, self.attack_animation_timer - 1)

    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), 20)
        hp_width = 30
        hp_height = 4
        hp_x = self.x - hp_width // 2
        hp_y = self.y - 35
        pygame.draw.rect(screen, HP_BAR_RED, (hp_x, hp_y, hp_width, hp_height))
        current_hp_width = int(hp_width * (self.hp / self.max_hp))
        pygame.draw.rect(screen, HP_BAR_GREEN, (hp_x, hp_y, current_hp_width, hp_height))

    def take_damage(self, damage):
        self.hp -= damage
        return self.hp <= 0

    def get_distance(self, other):
        return abs(self.x - other.x)

class Infantry(Unit):
    def __init__(self, row, col):
        super().__init__(row, col, 100, 12, 0, RED, 180, 200, 45)

    def attack(self, enemies):
        if self.attack_cooldown == 0:
            target = None
            min_distance = float('inf')
            for enemy in enemies:
                if enemy.row == self.row and enemy.x > self.x and self.get_distance(enemy) < self.attack_range:
                    distance = self.get_distance(enemy)
                    if distance < min_distance:
                        min_distance = distance
                        target = enemy
            if target:
                target.take_damage(self.damage)
                self.attack_cooldown = self.attack_interval
                self.attack_animation_timer = self.attack_animation_duration

    def draw(self, screen):
        super().draw(screen)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            line_surf = pygame.Surface((int(self.attack_range), 10), pygame.SRCALPHA)
            pygame.draw.line(line_surf, (255, 255, 255, alpha), (0, 5), (int(self.attack_range), 5), 3)
            screen.blit(line_surf, (self.x + 20, self.y - 5))

class Swordsman(Unit):
    def __init__(self, row, col):
        super().__init__(row, col, 150, 35, 0, GREEN, 180, 60, 30)

    def attack(self, enemies):
        if self.attack_cooldown == 0:
            for enemy in enemies:
                if enemy.row == self.row and enemy.x > self.x and self.get_distance(enemy) < self.attack_range:
                    enemy.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    self.attack_animation_timer = self.attack_animation_duration
                    break

    def draw(self, screen):
        super().draw(screen)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            arc_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
            pygame.draw.arc(arc_surf, (0, 255, 0, alpha), (5, 5, 50, 50), -0.5, 0.5, 5)
            screen.blit(arc_surf, (self.x, self.y - 30))

class Artillery(Unit):
    def __init__(self, row, col):
        super().__init__(row, col, 60, 50, 0, ORANGE, 380, 800, 120)
        self.attack_animation_duration = 20

    def attack(self, enemies, artillery_bullets):
        if self.attack_cooldown == 0:
            target = None
            max_x = 0
            for enemy in enemies:
                if enemy.row == self.row and enemy.x > self.x and enemy.x > max_x:
                    max_x = enemy.x
                    target = enemy
            if target:
                artillery_bullets.append(ArtilleryBullet(self.x+25, self.y, target.x, target.y, self.damage))
                self.attack_cooldown = self.attack_interval
                self.attack_animation_timer = self.attack_animation_duration

    def draw(self, screen):
        super().draw(screen)
        pygame.draw.rect(screen, (180, 100, 0), (self.x-5, self.y-3, 25, 6), border_radius=2)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            glow_surf = pygame.Surface((40, 40), pygame.SRCALPHA)
            pygame.draw.circle(glow_surf, (255, 200, 0, alpha), (20, 20), 18, 2)
            screen.blit(glow_surf, (self.x + 10, self.y - 20))

class Logistics(Unit):
    def __init__(self, row, col):
        super().__init__(row, col, 40, 0, 0, GRAY, 180, 0, 0)

    def attack(self, enemies):
        pass

    def draw(self, screen):
        super().draw(screen)
        pygame.draw.line(screen, WHITE, (self.x-8,self.y), (self.x+8,self.y), 2)
        pygame.draw.line(screen, WHITE, (self.x,self.y-8), (self.x,self.y+8), 2)

class Shieldman(Unit):
    def __init__(self, row, col):
        super().__init__(row, col, 300, 5, 0, BROWN, 190, 35, 60)
        self.heal_animation_timer = 0
        self.heal_cost = 20
        self.heal_amount = 30

    def update(self):
        super().update()
        self.heal_animation_timer = max(0, self.heal_animation_timer - 1)

    def heal_self(self):
        if self.hp < self.max_hp and game_state["resources"] >= self.heal_cost:
            self.hp = min(self.max_hp, self.hp + self.heal_amount)
            game_state["resources"] -= self.heal_cost
            self.heal_animation_timer = 20
            return True
        return False

    def attack(self, enemies):
        if self.attack_cooldown == 0:
            for enemy in enemies:
                if enemy.row == self.row and self.get_distance(enemy) < self.attack_range:
                    enemy.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    break

    def draw(self, screen):
        super().draw(screen)
        pygame.draw.circle(screen, (101, 67, 33), (int(self.x), int(self.y)), 25, 3)
        if self.heal_animation_timer > 0:
            alpha = int(180 * (self.heal_animation_timer / 20))
            glow_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
            pygame.draw.circle(glow_surf, (0, 255, 0, alpha), (30, 30), 28, 2)
            screen.blit(glow_surf, (self.x - 30, self.y - 30))

class Sniper(Unit):
    def __init__(self, row, col):
        super().__init__(row, col, 40, 2000, 0, (0, 100, 0), 1060, 2000, 450)
        self.attack_animation_duration = 30
        self.target = None

    def attack(self, enemies):
        if self.attack_cooldown == 0:
            target = None
            min_distance = float('inf')
            for enemy in enemies:
                if enemy.x > self.x:
                    distance = self.get_distance(enemy)
                    if distance < min_distance:
                        min_distance = distance
                        target = enemy
            if target:
                target.take_damage(self.damage)
                self.attack_cooldown = self.attack_interval
                self.attack_animation_timer = self.attack_animation_duration
                self.target = target
            else:
                self.target = None

    def draw(self, screen):
        super().draw(screen)
        pygame.draw.line(screen, WHITE, (int(self.x)-10, int(self.y)), (int(self.x)+10, int(self.y)), 1)
        pygame.draw.line(screen, WHITE, (int(self.x), int(self.y)-10), (int(self.x), int(self.y)+10), 1)

class Medic(Unit):
    def __init__(self, row, col):
        super().__init__(row, col, 50, 0, 0, (255, 100, 100), 180, 150, 90)
        self.heal_cooldown = 0
        self.heal_interval = 90
        self.heal_amount = 20
        self.heal_animation_timer = 0

    def update(self):
        super().update()
        self.heal_cooldown = max(0, self.heal_cooldown - 1)
        self.heal_animation_timer = max(0, self.heal_animation_timer - 1)

    def heal(self, red_armies):
        if self.heal_cooldown == 0:
            target = None
            min_hp_ratio = 1.0
            for army in red_armies:
                if army != self and army.row == self.row and army.hp < army.max_hp:
                    hp_ratio = army.hp / army.max_hp
                    if hp_ratio < min_hp_ratio:
                        min_hp_ratio = hp_ratio
                        target = army
            if target:
                target.hp = min(target.max_hp, target.hp + self.heal_amount)
                self.heal_cooldown = self.heal_interval
                self.heal_animation_timer = 15

    def draw(self, screen):
        super().draw(screen)
        pygame.draw.rect(screen, WHITE, (self.x-7, self.y-2, 14, 4), border_radius=1)
        pygame.draw.rect(screen, WHITE, (self.x-2, self.y-7, 4, 14), border_radius=1)
        if self.heal_animation_timer > 0:
            alpha = int(200 * (self.heal_animation_timer / 15))
            heal_surf = pygame.Surface((50, 50), pygame.SRCALPHA)
            pygame.draw.circle(heal_surf, (100, 255, 100, alpha), (25, 25), 22, 2)
            screen.blit(heal_surf, (self.x - 25, self.y - 25))

class Enemy(Unit):
    def __init__(self, row):
        super().__init__(row, COLS, 180, 8, 0.6, BLUE, 0, 45, 50)
        self.x = OFFSET_X + COLS * CELL_WIDTH + 20
        self.rect.x = self.x - 20

    def update(self, red_armies):
        super().update()
        can_move = True
        for army in red_armies:
            if army.row == self.row:
                army_left = army.x - 20
                army_right = army.x + 20
                next_x = self.x - self.speed
                enemy_left = next_x - 20
                enemy_right = next_x + 20
                if enemy_right > army_left and enemy_left < army_right and enemy_left < army_right:
                    can_move = False
                    break
        if can_move:
            self.x -= self.speed
            self.rect.x = self.x - 20

    def attack(self, red_armies):
        if self.attack_cooldown == 0:
            for army in red_armies:
                if army.row == self.row and self.get_distance(army) < self.attack_range:
                    army.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    self.attack_animation_timer = self.attack_animation_duration
                    break

    def draw(self, screen):
        super().draw(screen)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            line_surf = pygame.Surface((int(self.attack_range), 10), pygame.SRCALPHA)
            pygame.draw.line(line_surf, (0, 150, 255, alpha), (0, 5), (int(self.attack_range), 5), 3)
            screen.blit(line_surf, (self.x - self.attack_range - 20, self.y - 5))

class FastEnemy(Unit):
    def __init__(self, row):
        super().__init__(row, COLS, 50, 900, 10, PURPLE, 0, 40, 40)
        self.x = OFFSET_X + COLS * CELL_WIDTH + 20
        self.rect.x = self.x - 20

    def update(self, red_armies):
        super().update()
        can_move = True
        for army in red_armies:
            if army.row == self.row:
                army_left = army.x - 20
                army_right = army.x + 20
                next_x = self.x - self.speed
                enemy_left = next_x - 20
                enemy_right = next_x + 20
                if enemy_right > army_left and enemy_left < army_right and enemy_left < army_right:
                    can_move = False
                    break
        if can_move:
            self.x -= self.speed
            self.rect.x = self.x - 20

    def attack(self, red_armies):
        if self.attack_cooldown == 0:
            for army in red_armies:
                if army.row == self.row and self.get_distance(army) < self.attack_range:
                    army.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    self.attack_animation_timer = self.attack_animation_duration
                    break

    def draw(self, screen):
        super().draw(screen)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            arc_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
            pygame.draw.arc(arc_surf, (180, 0, 255, alpha), (5, 15, 50, 50), -0.3, 0.8, 4)
            screen.blit(arc_surf, (self.x - 50, self.y - 30))

class HeavyEnemy(Unit):
    def __init__(self, row):
        super().__init__(row, COLS, 2043, 180, 0.3, (50, 50, 50), 0, 50, 70)
        self.x = OFFSET_X + COLS * CELL_WIDTH + 20
        self.rect.x = self.x - 20

    def update(self, red_armies):
        super().update()
        can_move = True
        for army in red_armies:
            if army.row == self.row:
                army_left = army.x - 20
                army_right = army.x + 20
                next_x = self.x - self.speed
                enemy_left = next_x - 20
                enemy_right = next_x + 20
                if enemy_right > army_left and enemy_left < army_right and enemy_left < army_right:
                    can_move = False
                    break
        if can_move:
            self.x -= self.speed
            self.rect.x = self.x - 20

    def attack(self, red_armies):
        if self.attack_cooldown == 0:
            for army in red_armies:
                if army.row == self.row and self.get_distance(army) < self.attack_range:
                    army.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    self.attack_animation_timer = self.attack_animation_duration
                    break

    def draw(self, screen):
        super().draw(screen)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            impact_surf = pygame.Surface((80, 80), pygame.SRCALPHA)
            pygame.draw.circle(impact_surf, (100, 100, 100, alpha), (40, 40), 35, 4)
            pygame.draw.circle(impact_surf, (150, 150, 150, alpha), (40, 40), 25, 2)
            screen.blit(impact_surf, (self.x - 70, self.y - 40))

class OfficerEnemy(Unit):
    def __init__(self, row):
        super().__init__(row, COLS, 800, 12, 0.8, LIGHT_RED, 0, 45, 45)
        self.x = OFFSET_X + COLS * CELL_WIDTH + 20
        self.rect.x = self.x - 20
        self.original_speed = 0.8
        self.aura_range = 100

    def update(self, red_armies, enemies_list):
        super().update()
        can_move = True
        for army in red_armies:
            if army.row == self.row:
                army_left = army.x - 20
                army_right = army.x + 20
                next_x = self.x - self.speed
                enemy_left = next_x - 20
                enemy_right = next_x + 20
                if enemy_right > army_left and enemy_left < army_right and enemy_left < army_right:
                    can_move = False
                    break
        if can_move:
            self.x -= self.speed
            self.rect.x = self.x - 20
        
        for enemy in enemies_list:
            if enemy != self and self.get_distance(enemy) < self.aura_range:
                if not hasattr(enemy, 'original_speed'):
                    enemy.original_speed = enemy.speed
                enemy.speed = enemy.original_speed * 1.2

    def attack(self, red_armies):
        if self.attack_cooldown == 0:
            for army in red_armies:
                if army.row == self.row and self.get_distance(army) < self.attack_range:
                    army.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    self.attack_animation_timer = self.attack_animation_duration
                    break

    def draw(self, screen):
        super().draw(screen)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            line_surf = pygame.Surface((int(self.attack_range), 12), pygame.SRCALPHA)
            pygame.draw.line(line_surf, (255, 100, 100, alpha), (0, 6), (int(self.attack_range), 6), 4)
            screen.blit(line_surf, (self.x - self.attack_range - 20, self.y - 6))
            glow_surf = pygame.Surface((40, 40), pygame.SRCALPHA)
            pygame.draw.circle(glow_surf, (255, 50, 50, alpha), (20, 20), 18, 2)
            screen.blit(glow_surf, (self.x - 20, self.y - 20))

class BomberEnemy(Unit):
    def __init__(self, row):
        super().__init__(row, COLS, 30, 40, 3.0, (80, 80, 80), 0, 50, 80)
        self.x = OFFSET_X + COLS * CELL_WIDTH + 20
        self.rect.x = self.x - 20
        self.explosion_timer = 0

    def update(self, red_armies):
        super().update()
        if self.explosion_timer > 0:
            self.explosion_timer -= 1
            return
        can_move = True
        for army in red_armies:
            if army.row == self.row:
                army_left = army.x - 20
                army_right = army.x + 20
                next_x = self.x - self.speed
                enemy_left = next_x - 20
                enemy_right = next_x + 20
                if enemy_right > army_left and enemy_left < army_right and enemy_left < army_right:
                    can_move = False
                    break
        if can_move:
            self.x -= self.speed
            self.rect.x = self.x - 20

    def attack(self, red_armies):
        if self.attack_cooldown == 0:
            for army in red_armies:
                if army.row == self.row and self.get_distance(army) < self.attack_range:
                    army.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    self.attack_animation_timer = self.attack_animation_duration
                    self.explosion_timer = 20
                    break

    def draw(self, screen):
        super().draw(screen)
        if self.explosion_timer > 0:
            alpha = int(255 * (self.explosion_timer / 20))
            explosion_surf = pygame.Surface((100, 100), pygame.SRCALPHA)
            pygame.draw.circle(explosion_surf, (255, 150, 0, alpha), (50, 50), 45, 4)
            pygame.draw.circle(explosion_surf, (255, 255, 0, alpha), (50, 50), 30, 3)
            pygame.draw.circle(explosion_surf, (255, 255, 255, alpha), (50, 50), 15, 2)
            screen.blit(explosion_surf, (self.x - 50, self.y - 50))
        elif self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            glow_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
            pygame.draw.circle(glow_surf, (255, 100, 0, alpha), (30, 30), 25, 3)
            screen.blit(glow_surf, (self.x - 30, self.y - 30))

class ArcherEnemy(Unit):
    def __init__(self, row):
        super().__init__(row, COLS, 200, 15, 0.5, (139, 90, 43), 0, 250, 60)
        self.x = OFFSET_X + COLS * CELL_WIDTH + 20
        self.rect.x = self.x - 20

    def update(self, red_armies):
        super().update()
        can_move = True
        for army in red_armies:
            if army.row == self.row:
                army_left = army.x - 20
                army_right = army.x + 20
                next_x = self.x - self.speed
                enemy_left = next_x - 20
                enemy_right = next_x + 20
                if enemy_right > army_left and enemy_left < army_right and enemy_left < army_right:
                    can_move = False
                    break
        if can_move:
            self.x -= self.speed
            self.rect.x = self.x - 20

    def attack(self, red_armies):
        if self.attack_cooldown == 0:
            for army in red_armies:
                if army.row == self.row and self.get_distance(army) < self.attack_range:
                    army.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    self.attack_animation_timer = self.attack_animation_duration
                    break

    def draw(self, screen):
        super().draw(screen)
        pygame.draw.arc(screen, WHITE, (self.x-15, self.y-10, 20, 20), -1.5, 0.5, 2)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            line_surf = pygame.Surface((int(self.attack_range), 6), pygame.SRCALPHA)
            pygame.draw.line(line_surf, (200, 200, 200, alpha), (0, 3), (int(self.attack_range), 3), 2)
            screen.blit(line_surf, (self.x - self.attack_range - 20, self.y - 3))
            arrow_surf = pygame.Surface((20, 20), pygame.SRCALPHA)
            pygame.draw.polygon(arrow_surf, (180, 180, 180, alpha), [(0, 10), (15, 5), (15, 15)])
            screen.blit(arrow_surf, (self.x - self.attack_range - 20, self.y - 10))

class GeneralEnemy(Unit):
    def __init__(self, row):
        super().__init__(row, COLS, 3000, 141, 0.5, (220, 200, 0), 0, 55, 50)
        self.x = OFFSET_X + COLS * CELL_WIDTH + 20
        self.rect.x = self.x - 20
        self.aura_range = 120

    def update(self, red_armies, enemies_list):
        super().update()
        can_move = True
        for army in red_armies:
            if army.row == self.row:
                army_left = army.x - 20
                army_right = army.x + 20
                next_x = self.x - self.speed
                enemy_left = next_x - 20
                enemy_right = next_x + 20
                if enemy_right > army_left and enemy_left < army_right and enemy_left < army_right:
                    can_move = False
                    break
        if can_move:
            self.x -= self.speed
            self.rect.x = self.x - 20

    def attack(self, red_armies):
        if self.attack_cooldown == 0:
            for army in red_armies:
                if army.row == self.row and self.get_distance(army) < self.attack_range:
                    army.take_damage(self.damage)
                    self.attack_cooldown = self.attack_interval
                    self.attack_animation_timer = self.attack_animation_duration
                    break

    def draw(self, screen):
        super().draw(screen)
        pygame.draw.polygon(screen, (220, 200, 0), [(self.x-10, self.y+5), (self.x-5, self.y-8), (self.x, self.y+3), (self.x+5, self.y-8), (self.x+10, self.y+5)], 2)
        if self.attack_animation_timer > 0:
            alpha = int(255 * (self.attack_animation_timer / self.attack_animation_duration))
            line_surf = pygame.Surface((int(self.attack_range), 14), pygame.SRCALPHA)
            pygame.draw.line(line_surf, (255, 215, 0, alpha), (0, 7), (int(self.attack_range), 7), 5)
            screen.blit(line_surf, (self.x - self.attack_range - 20, self.y - 7))
            glow_surf = pygame.Surface((50, 50), pygame.SRCALPHA)
            pygame.draw.circle(glow_surf, (255, 200, 0, alpha), (25, 25), 22, 2)
            screen.blit(glow_surf, (self.x - 25, self.y - 25))

class Button:
    def __init__(self, text, color, hover_color, x, y, width, height):
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.rect = pygame.Rect(x, y, width, height)
        self.txt_surface = button_font.render(text, True, WHITE)
        self.txt_rect = self.txt_surface.get_rect(center=self.rect.center)

    def draw(self, screen):
        mouse_pos = pygame.mouse.get_pos()
        current_color = self.hover_color if self.rect.collidepoint(mouse_pos) else self.color
        pygame.draw.rect(screen, current_color, self.rect, border_radius=10)
        screen.blit(self.txt_surface, self.txt_rect)

    def is_clicked(self, event):
        return event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.rect.collidepoint(event.pos)

start_btn = Button("开始长征", BLUE, LIGHT_BLUE, SCREEN_WIDTH//2 - 150, 280, 300, 70)
quit_btn = Button("退出长征", RED, LIGHT_RED, SCREEN_WIDTH//2 - 150, 380, 300, 70)
restart_btn = Button("返回瑞金", BLUE, LIGHT_BLUE, SCREEN_WIDTH//2 - 150, 400, 300, 70)
menu_btn = Button("返回根据地", GRAY, (150,150,150), SCREEN_WIDTH//2 - 150, 500, 300, 70)

unit_types = [Infantry, Swordsman, Artillery, Logistics, Shieldman, Sniper, Medic]
unit_names = ["步兵", "刀兵", "炮兵", "后勤兵", "盾兵", "狙击兵", "医疗兵"]
unit_colors = [RED, GREEN, ORANGE, GRAY, BROWN, (0, 100, 0), (255, 100, 100)]

enemy_types = [Enemy, FastEnemy, HeavyEnemy, OfficerEnemy, BomberEnemy, ArcherEnemy, GeneralEnemy]

def battle_xiangjiang():
    global enemies
    running = True
    game_over = False
    game_victory = False
    clock = pygame.time.Clock()

    ra = []
    es = []
    bs = []
    art_bs = []
    oc = set()

    est = 0
    esi = 150
    rt = 0
    ri = 150

    cui = 0

    MW = 15
    epw = 12
    esd = 0
    wave_complete = False

    while running:
        if level1_bg:
            screen.blit(level1_bg, (0, 0))
        else:
            screen.fill((0, 120, 0))
        
        for col in range(COLS+1):
            x = OFFSET_X + col*CELL_WIDTH
            pygame.draw.line(screen, GRID_COLOR, (x,OFFSET_Y), (x,OFFSET_Y+ROWS*CELL_HEIGHT), 1)
        for row in range(ROWS+1):
            y = OFFSET_Y + row*CELL_HEIGHT
            pygame.draw.line(screen, GRID_COLOR, (OFFSET_X,y), (OFFSET_X+COLS*CELL_WIDTH,y), 1)
        
        screen.blit(button_font.render("血战湘江", True, RED), (20, 10))
        screen.blit(small_font.render(f"资源: {game_state['resources']}", True, WHITE), (20, 70))
        screen.blit(small_font.render(f"波次: {min(game_state['wave'], MW)}/{MW}", True, WHITE), (20, 110))
        
        lc = sum(1 for army in ra if isinstance(army, Logistics))
        screen.blit(small_font.render(f"后勤兵: {lc} (+{lc*10}/1.67s)", True, GRAY), (20, 150))
        
        pygame.draw.rect(screen, (50,50,50), (20, 200, 180, 300), border_radius=5)
        screen.blit(small_font.render("兵种选择", True, WHITE), (30, 205))

        for i in range(7):
            y_pos = 240 + i*40
            if i == cui:
                pygame.draw.rect(screen, (100,100,100), (25, y_pos, 170, 35), border_radius=3)
            pygame.draw.circle(screen, unit_colors[i], (40, y_pos+17), 10)
            screen.blit(tiny_font.render(f"{i+1}. {unit_names[i]} ({unit_types[i](0,0).cost})", True, WHITE), (60, y_pos+7))

        screen.blit(small_font.render("点击草坪放置单位 | 按 ESC 返回", True, WHITE), (20, SCREEN_HEIGHT-40))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_1: cui = 0
                if event.key == pygame.K_2: cui = 1
                if event.key == pygame.K_3: cui = 2
                if event.key == pygame.K_4: cui = 3
                if event.key == pygame.K_5: cui = 4
                if event.key == pygame.K_6: cui = 5
                if event.key == pygame.K_7: cui = 6
            
            if not game_over and not game_victory and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_x, mouse_y = event.pos
                
                for army in ra:
                    if isinstance(army, Shieldman):
                        if abs(mouse_x - army.x) < 25 and abs(mouse_y - army.y) < 25:
                            army.heal_self()
                            break
                
                col = (mouse_x - OFFSET_X) // CELL_WIDTH
                row = (mouse_y - OFFSET_Y) // CELL_HEIGHT

                if 0<=col<COLS and 0<=row<ROWS and row not in [3,4] and (row,col) not in oc:
                    unit = unit_types[cui](row, col)
                    if game_state["resources"] >= unit.cost:
                        ra.append(unit)
                        oc.add((row, col))
                        game_state["resources"] -= unit.cost
            
            if game_over or game_victory:
                if restart_btn.is_clicked(event):
                    game_state.update({"resources":150, "score":0, "wave":1})
                    battle_xiangjiang()
                    running = False
                if menu_btn.is_clicked(event):
                    running = False
        
        if not game_over and not game_victory:
            wave = game_state["wave"]
            if wave <= MW:
                est += 1
                if est >= esi:
                    est = 0
                    spawn_row = random.choice([0,1,2,5,6,7])

                    if wave <= 2:
                        es.append(Enemy(spawn_row))
                    elif wave <= 4:
                        r = random.random()
                        if r < 0.6:
                            es.append(Enemy(spawn_row))
                        elif r < 0.85:
                            es.append(FastEnemy(spawn_row))
                        else:
                            es.append(BomberEnemy(spawn_row))
                    elif wave <= 7:
                        r = random.random()
                        if r < 0.4:
                            es.append(Enemy(spawn_row))
                        elif r < 0.6:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.75:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.85:
                            es.append(BomberEnemy(spawn_row))
                        else:
                            es.append(ArcherEnemy(spawn_row))
                    elif wave <= 10:
                        r = random.random()
                        if r < 0.25:
                            es.append(Enemy(spawn_row))
                        elif r < 0.4:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.55:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.65:
                            es.append(BomberEnemy(spawn_row))
                        elif r < 0.8:
                            es.append(ArcherEnemy(spawn_row))
                        elif r < 0.9:
                            es.append(OfficerEnemy(spawn_row))
                        else:
                            es.append(GeneralEnemy(spawn_row))
                    else:
                        r = random.random()
                        if r < 0.15:
                            es.append(Enemy(spawn_row))
                        elif r < 0.25:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.4:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.5:
                            es.append(BomberEnemy(spawn_row))
                        elif r < 0.65:
                            es.append(ArcherEnemy(spawn_row))
                        elif r < 0.8:
                            es.append(OfficerEnemy(spawn_row))
                        else:
                            es.append(GeneralEnemy(spawn_row))

                    esd += 1

                    if esd >= wave * epw:
                        game_state["wave"] += 1
                        esi = max(60, esi - 5)

            if game_state["wave"] > MW and len(es) == 0:
                game_victory = True
            
            rt += 1
            if rt >= ri:
                rt = 0
                game_state["resources"] += lc * 10
            
            for army in ra[:]:
                army.update()
                if isinstance(army, Sniper):
                    target = None
                    min_distance = float('inf')
                    for enemy in es:
                        if enemy.x > army.x:
                            distance = army.get_distance(enemy)
                            if distance < min_distance:
                                min_distance = distance
                                target = enemy
                    army.target = target
                if isinstance(army, Artillery):
                    army.attack(es, art_bs)
                elif isinstance(army, Medic):
                    army.heal(ra)
                else:
                    army.attack(es)

                if army.hp <= 0:
                    ra.remove(army)
                    oc.remove((army.row, army.col))

            for ab in art_bs[:]:
                if ab.update() == False:
                    if ab.explosion_timer > 0:
                        for enemy in es[:]:
                            if abs(enemy.x - ab.target_x) < 50 and abs(enemy.y - ab.target_y) < 50:
                                if enemy.take_damage(ab.damage):
                                    es.remove(enemy)
                                    game_state["score"] += 10
                                    game_state["resources"] += 15
                    art_bs.remove(ab)
            
            for bullet in bs[:]:
                bullet.update()
                if bullet.x > SCREEN_WIDTH:
                    bs.remove(bullet)
                    continue
                for enemy in es[:]:
                    if bullet.rect.colliderect(enemy.rect):
                        enemy.take_damage(bullet.damage)
                        bs.remove(bullet)
                        break
            
            for enemy in es[:]:
                if isinstance(enemy, OfficerEnemy) or isinstance(enemy, GeneralEnemy):
                    enemy.update(ra, es)
                else:
                    enemy.update(ra)
                enemy.attack(ra)
                
                if enemy.x < OFFSET_X:
                    game_over = True
                
                if enemy.hp <= 0:
                    es.remove(enemy)
                    game_state["score"] += 10
                    game_state["resources"] += 15
        
        for army in ra:
            army.draw(screen)
        for bullet in bs:
            bullet.draw(screen)
        for ab in art_bs:
            ab.draw(screen)
        for enemy in es:
            enemy.draw(screen)
        
        for army in ra:
            if isinstance(army, Swordsman) and army.attack_animation_timer > 0:
                alpha = int(255 * (army.attack_animation_timer / army.attack_animation_duration))
                arc_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
                pygame.draw.arc(arc_surf, (0, 255, 0, alpha), (5, 5, 50, 50), -0.5, 0.5, 5)
                screen.blit(arc_surf, (army.x, army.y - 30))
        
        for army in ra:
            if isinstance(army, Sniper) and army.target and army.target.hp > 0:
                pygame.draw.circle(screen, (255, 0, 0), (int(army.target.x), int(army.target.y)), 15, 4)
                pygame.draw.circle(screen, (255, 100, 100), (int(army.target.x), int(army.target.y)), 8)
                pygame.draw.line(screen, (255, 0, 0), (int(army.target.x)-20, int(army.target.y)), (int(army.target.x)+20, int(army.target.y)), 2)
                pygame.draw.line(screen, (255, 0, 0), (int(army.target.x), int(army.target.y)-20), (int(army.target.x), int(army.target.y)+20), 2)
        
        if game_over:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill(OVERLAY_COLOR)
            screen.blit(overlay, (0, 0))
            
            over_title = title_font.render("游戏失败", True, RED)
            screen.blit(over_title, over_title.get_rect(center=(SCREEN_WIDTH//2, 200)))
            
            screen.blit(small_font.render(f"最终波次: {game_state['wave']}", True, WHITE), (SCREEN_WIDTH//2-80, 300))
            screen.blit(small_font.render(f"最终得分: {game_state['score']}", True, WHITE), (SCREEN_WIDTH//2-80, 340))
            
            restart_btn.draw(screen)
            menu_btn.draw(screen)
        
        if game_victory:
            game_state["completed_levels"].add(1)
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 50, 0, 180))
            screen.blit(overlay, (0, 0))
            
            victory_title = title_font.render("胜利!", True, YELLOW)
            screen.blit(victory_title, victory_title.get_rect(center=(SCREEN_WIDTH//2, 150)))
            
            victory_subtitle = button_font.render("血战湘江胜利完成!", True, GREEN)
            screen.blit(victory_subtitle, victory_subtitle.get_rect(center=(SCREEN_WIDTH//2, 250)))
            
            screen.blit(small_font.render(f"最终波次: {MW}/{MW}", True, WHITE), (SCREEN_WIDTH//2-80, 320))
            screen.blit(small_font.render(f"最终得分: {game_state['score']}", True, WHITE), (SCREEN_WIDTH//2-80, 360))
            screen.blit(small_font.render(f"剩余资源: {game_state['resources']}", True, WHITE), (SCREEN_WIDTH//2-80, 400))
            
            restart_btn.draw(screen)
            menu_btn.draw(screen)
        
        pygame.display.flip()
        clock.tick(60)

def battle_snow_mountain():
    running = True
    game_over = False
    game_victory = False
    clock = pygame.time.Clock()

    ROWS_SNOW = 5
    COLS_SNOW = 9
    CELL_WIDTH_SNOW = 102
    CELL_HEIGHT_SNOW = 95
    OFFSET_X_SNOW = 280
    OFFSET_Y_SNOW = 100

    ra = []
    es = []
    bs = []
    art_bs = []
    oc = set()

    est = 0
    esi = 150
    rt = 0
    ri = 100

    cui = 0

    MW = 15
    epw = 12
    esd = 0
    wave_complete = False

    cold_timer = 0
    cold_interval = 180

    while running:
        if level2_bg:
            screen.blit(level2_bg, (0, 0))
        else:
            screen.fill((200, 200, 255))

        for col in range(COLS_SNOW+1):
            x = OFFSET_X_SNOW + col*CELL_WIDTH_SNOW
            pygame.draw.line(screen, GRID_COLOR, (x,OFFSET_Y_SNOW), (x,OFFSET_Y_SNOW+ROWS_SNOW*CELL_HEIGHT_SNOW), 1)
        for row in range(ROWS_SNOW+1):
            y = OFFSET_Y_SNOW + row*CELL_HEIGHT_SNOW
            pygame.draw.line(screen, GRID_COLOR, (OFFSET_X_SNOW,y), (OFFSET_X_SNOW+COLS_SNOW*CELL_WIDTH_SNOW,y), 1)

        screen.blit(button_font.render("翻雪山", True, WHITE), (20, 10))
        screen.blit(small_font.render(f"资源: {game_state['resources']}", True, WHITE), (20, 70))
        screen.blit(small_font.render(f"波次: {min(game_state['wave'], MW)}/{MW}", True, WHITE), (20, 110))
        screen.blit(small_font.render("寒冷: 士兵持续掉血", True, LIGHT_BLUE), (20, 150))
        
        lc = sum(1 for army in ra if isinstance(army, Logistics))
        screen.blit(small_font.render(f"后勤兵: {lc} (+{lc*10}/1.67s)", True, GRAY), (20, 190))
        
        pygame.draw.rect(screen, (50,50,50), (20, 230, 180, 300), border_radius=5)
        screen.blit(small_font.render("兵种选择", True, WHITE), (30, 235))

        for i in range(7):
            y_pos = 270 + i*40
            if i == cui:
                pygame.draw.rect(screen, (100,100,100), (25, y_pos, 170, 35), border_radius=3)
            pygame.draw.circle(screen, unit_colors[i], (40, y_pos+17), 10)
            screen.blit(tiny_font.render(f"{i+1}. {unit_names[i]} ({unit_types[i](0,0).cost})", True, WHITE), (60, y_pos+7))

        screen.blit(small_font.render("点击格子放置单位 | 按 ESC 返回", True, WHITE), (20, SCREEN_HEIGHT-40))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_1: cui = 0
                if event.key == pygame.K_2: cui = 1
                if event.key == pygame.K_3: cui = 2
                if event.key == pygame.K_4: cui = 3
                if event.key == pygame.K_5: cui = 4
                if event.key == pygame.K_6: cui = 5
                if event.key == pygame.K_7: cui = 6
            
            if not game_over and not game_victory and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_x, mouse_y = event.pos
                
                for army in ra:
                    if isinstance(army, Shieldman):
                        if abs(mouse_x - army.x) < 25 and abs(mouse_y - army.y) < 25:
                            army.heal_self()
                            break
                
                col = (mouse_x - OFFSET_X_SNOW) // CELL_WIDTH_SNOW
                row = (mouse_y - OFFSET_Y_SNOW) // CELL_HEIGHT_SNOW

                if 0<=col<COLS_SNOW and 0<=row<ROWS_SNOW and (row,col) not in oc:
                    unit = unit_types[cui](row, col)
                    unit.x = OFFSET_X_SNOW + col * CELL_WIDTH_SNOW + CELL_WIDTH_SNOW // 2
                    unit.y = OFFSET_Y_SNOW + row * CELL_HEIGHT_SNOW + CELL_HEIGHT_SNOW // 2
                    unit.rect.x = unit.x - 20
                    unit.rect.y = unit.y - 25
                    unit.row = row
                    unit.col = col
                    if game_state["resources"] >= unit.cost:
                        ra.append(unit)
                        oc.add((row, col))
                        game_state["resources"] -= unit.cost
            
            if game_over or game_victory:
                if restart_btn.is_clicked(event):
                    game_state.update({"resources":150, "score":0, "wave":1, "level":2})
                    battle_snow_mountain()
                    running = False
                if menu_btn.is_clicked(event):
                    running = False
        
        if not game_over and not game_victory:
            cold_timer += 1
            if cold_timer >= cold_interval:
                cold_timer = 0
                for army in ra:
                    if not isinstance(army, Logistics):
                        army.hp = max(0, army.hp - 5)
                        if army.hp <= 0:
                            ra.remove(army)
                            oc.remove((army.row, army.col))
            
            wave = game_state["wave"]
            if wave <= MW:
                est += 1
                if est >= esi:
                    est = 0
                    spawn_row = random.choice(range(ROWS_SNOW))

                    if wave <= 2:
                        es.append(Enemy(spawn_row))
                    elif wave <= 4:
                        r = random.random()
                        if r < 0.6:
                            es.append(Enemy(spawn_row))
                        elif r < 0.85:
                            es.append(FastEnemy(spawn_row))
                        else:
                            es.append(BomberEnemy(spawn_row))
                    elif wave <= 7:
                        r = random.random()
                        if r < 0.4:
                            es.append(Enemy(spawn_row))
                        elif r < 0.6:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.75:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.85:
                            es.append(BomberEnemy(spawn_row))
                        else:
                            es.append(ArcherEnemy(spawn_row))
                    elif wave <= 10:
                        r = random.random()
                        if r < 0.25:
                            es.append(Enemy(spawn_row))
                        elif r < 0.4:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.55:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.65:
                            es.append(BomberEnemy(spawn_row))
                        elif r < 0.8:
                            es.append(ArcherEnemy(spawn_row))
                        elif r < 0.9:
                            es.append(OfficerEnemy(spawn_row))
                        else:
                            es.append(GeneralEnemy(spawn_row))
                    else:
                        r = random.random()
                        if r < 0.15:
                            es.append(Enemy(spawn_row))
                        elif r < 0.25:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.4:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.5:
                            es.append(BomberEnemy(spawn_row))
                        elif r < 0.65:
                            es.append(ArcherEnemy(spawn_row))
                        elif r < 0.8:
                            es.append(OfficerEnemy(spawn_row))
                        else:
                            es.append(GeneralEnemy(spawn_row))

                    es[-1].x = OFFSET_X_SNOW + COLS_SNOW * CELL_WIDTH_SNOW + 20
                    es[-1].y = OFFSET_Y_SNOW + spawn_row * CELL_HEIGHT_SNOW + CELL_HEIGHT_SNOW // 2
                    es[-1].rect.x = es[-1].x - 20
                    es[-1].rect.y = es[-1].y - 25

                    esd += 1

                    if esd >= wave * epw:
                        game_state["wave"] += 1
                        esi = max(60, esi - 5)

            if game_state["wave"] > MW and len(es) == 0:
                game_victory = True
            
            rt += 1
            if rt >= ri:
                rt = 0
                game_state["resources"] += lc * 10
            
            for army in ra[:]:
                army.update()
                
                snow_attack_interval = int(army.attack_interval * 1.1)
                
                if isinstance(army, Sniper):
                    target = None
                    min_distance = float('inf')
                    for enemy in es:
                        if enemy.x > army.x:
                            distance = army.get_distance(enemy)
                            if distance < min_distance:
                                min_distance = distance
                                target = enemy
                    army.target = target
                    if army.attack_cooldown == 0:
                        if target:
                            target.take_damage(army.damage)
                            army.attack_cooldown = snow_attack_interval
                            army.attack_animation_timer = army.attack_animation_duration
                elif isinstance(army, Artillery):
                    if army.attack_cooldown == 0:
                        target = None
                        max_x = 0
                        for enemy in es:
                            if abs(enemy.y - army.y) < 30 and enemy.x > army.x and enemy.x > max_x:
                                max_x = enemy.x
                                target = enemy
                        if target:
                            art_bs.append(ArtilleryBullet(army.x+25, army.y, target.x, target.y, army.damage))
                            army.attack_cooldown = snow_attack_interval
                            army.attack_animation_timer = army.attack_animation_duration
                elif isinstance(army, Medic):
                    if army.heal_cooldown == 0:
                        target = None
                        min_hp_ratio = 1.0
                        for a in ra:
                            if a != army and abs(a.y - army.y) < 30 and a.hp < a.max_hp:
                                hp_ratio = a.hp / a.max_hp
                                if hp_ratio < min_hp_ratio:
                                    min_hp_ratio = hp_ratio
                                    target = a
                        if target:
                            target.hp = min(target.max_hp, target.hp + army.heal_amount)
                            army.heal_cooldown = army.heal_interval
                            army.heal_animation_timer = 15
                else:
                    if army.attack_cooldown == 0:
                        target = None
                        min_distance = float('inf')
                        for enemy in es:
                            if abs(enemy.y - army.y) < 30 and enemy.x > army.x:
                                distance = army.get_distance(enemy)
                                if distance < army.attack_range and distance < min_distance:
                                    min_distance = distance
                                    target = enemy
                        if target:
                            target.take_damage(army.damage)
                            army.attack_cooldown = snow_attack_interval
                            army.attack_animation_timer = army.attack_animation_duration

                if army.hp <= 0:
                    ra.remove(army)
                    oc.remove((army.row, army.col))

            for ab in art_bs[:]:
                if ab.update() == False:
                    if ab.explosion_timer > 0:
                        for enemy in es[:]:
                            if abs(enemy.x - ab.target_x) < 50 and abs(enemy.y - ab.target_y) < 50:
                                if enemy.take_damage(ab.damage):
                                    es.remove(enemy)
                                    game_state["score"] += 10
                                    game_state["resources"] += 15
                    art_bs.remove(ab)
            
            for bullet in bs[:]:
                bullet.update()
                if bullet.x > SCREEN_WIDTH:
                    bs.remove(bullet)
                    continue
                for enemy in es[:]:
                    if bullet.rect.colliderect(enemy.rect):
                        enemy.take_damage(bullet.damage)
                        bs.remove(bullet)
                        break
            
            for enemy in es[:]:
                can_move = True
                for army in ra:
                    if abs(enemy.y - army.y) < 30:
                        army_left = army.x - 20
                        army_right = army.x + 20
                        next_x = enemy.x - enemy.speed
                        enemy_left = next_x - 20
                        enemy_right = next_x + 20
                        if enemy_right > army_left and enemy_left < army_right:
                            can_move = False
                            break
                
                if can_move:
                    enemy.x -= enemy.speed
                    enemy.rect.x = enemy.x - 20
                
                enemy.attack_animation_timer = max(0, enemy.attack_animation_timer - 1)
                
                snow_enemy_attack_interval = int(enemy.attack_interval * 1.1)
                
                if enemy.attack_cooldown == 0:
                    for army in ra:
                        if abs(enemy.y - army.y) < 30 and enemy.get_distance(army) < enemy.attack_range:
                            army.take_damage(enemy.damage)
                            enemy.attack_cooldown = snow_enemy_attack_interval
                            enemy.attack_animation_timer = enemy.attack_animation_duration
                            break
                
                enemy.attack_cooldown = max(0, enemy.attack_cooldown - 1)
                
                if enemy.x < OFFSET_X_SNOW:
                    game_over = True
                
                if enemy.hp <= 0:
                    es.remove(enemy)
                    game_state["score"] += 10
                    game_state["resources"] += 15
        
        for army in ra:
            army.draw(screen)
        for bullet in bs:
            bullet.draw(screen)
        for ab in art_bs:
            ab.draw(screen)
        for enemy in es:
            enemy.draw(screen)
        
        for army in ra:
            if isinstance(army, Swordsman) and army.attack_animation_timer > 0:
                alpha = int(255 * (army.attack_animation_timer / army.attack_animation_duration))
                arc_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
                pygame.draw.arc(arc_surf, (0, 255, 0, alpha), (5, 5, 50, 50), -0.5, 0.5, 5)
                screen.blit(arc_surf, (army.x, army.y - 30))
        
        for army in ra:
            if isinstance(army, Sniper) and army.target and army.target.hp > 0:
                pygame.draw.circle(screen, (255, 0, 0), (int(army.target.x), int(army.target.y)), 15, 4)
                pygame.draw.circle(screen, (255, 100, 100), (int(army.target.x), int(army.target.y)), 8)
                pygame.draw.line(screen, (255, 0, 0), (int(army.target.x)-20, int(army.target.y)), (int(army.target.x)+20, int(army.target.y)), 2)
                pygame.draw.line(screen, (255, 0, 0), (int(army.target.x), int(army.target.y)-20), (int(army.target.x), int(army.target.y)+20), 2)
        
        if game_over:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill(OVERLAY_COLOR)
            screen.blit(overlay, (0, 0))
            
            over_title = title_font.render("游戏失败", True, RED)
            screen.blit(over_title, over_title.get_rect(center=(SCREEN_WIDTH//2, 200)))
            
            screen.blit(small_font.render(f"最终波次: {game_state['wave']}", True, WHITE), (SCREEN_WIDTH//2-80, 300))
            screen.blit(small_font.render(f"最终得分: {game_state['score']}", True, WHITE), (SCREEN_WIDTH//2-80, 340))
            
            restart_btn.draw(screen)
            menu_btn.draw(screen)
        
        if game_victory:
            game_state["completed_levels"].add(2)
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 50, 0, 180))
            screen.blit(overlay, (0, 0))
            
            victory_title = title_font.render("胜利!", True, YELLOW)
            screen.blit(victory_title, victory_title.get_rect(center=(SCREEN_WIDTH//2, 150)))
            
            victory_subtitle = button_font.render("翻雪山胜利完成!", True, GREEN)
            screen.blit(victory_subtitle, victory_subtitle.get_rect(center=(SCREEN_WIDTH//2, 250)))
            
            screen.blit(small_font.render(f"最终波次: {MW}/{MW}", True, WHITE), (SCREEN_WIDTH//2-80, 320))
            screen.blit(small_font.render(f"最终得分: {game_state['score']}", True, WHITE), (SCREEN_WIDTH//2-80, 360))
            screen.blit(small_font.render(f"剩余资源: {game_state['resources']}", True, WHITE), (SCREEN_WIDTH//2-80, 400))
            
            restart_btn.draw(screen)
            menu_btn.draw(screen)
        
        pygame.display.flip()
        clock.tick(60)

def battle_grassland():
    running = True
    game_over = False
    game_victory = False
    clock = pygame.time.Clock()

    ROWS_GRASS = 5
    COLS_GRASS = 9
    CELL_WIDTH_GRASS = 102
    CELL_HEIGHT_GRASS = 95
    OFFSET_X_GRASS = 280
    OFFSET_Y_GRASS = 100

    ra = []
    es = []
    bs = []
    art_bs = []
    oc = set()

    est = 0
    esi = 150
    rt = 0
    ri = 100

    cui = 0

    MW = 15
    epw = 12
    esd = 0
    wave_complete = False

    while running:
        if level3_bg:
            screen.blit(level3_bg, (0, 0))
        else:
            screen.fill((34, 139, 34))

        for col in range(COLS_GRASS+1):
            x = OFFSET_X_GRASS + col*CELL_WIDTH_GRASS
            pygame.draw.line(screen, GRID_COLOR, (x,OFFSET_Y_GRASS), (x,OFFSET_Y_GRASS+ROWS_GRASS*CELL_HEIGHT_GRASS), 1)
        for row in range(ROWS_GRASS+1):
            y = OFFSET_Y_GRASS + row*CELL_HEIGHT_GRASS
            pygame.draw.line(screen, GRID_COLOR, (OFFSET_X_GRASS,y), (OFFSET_X_GRASS+COLS_GRASS*CELL_WIDTH_GRASS,y), 1)

        screen.blit(button_font.render("过草地", True, GREEN), (20, 10))
        screen.blit(small_font.render(f"资源: {game_state['resources']}", True, WHITE), (20, 70))
        screen.blit(small_font.render(f"波次: {min(game_state['wave'], MW)}/{MW}", True, WHITE), (20, 110))
        screen.blit(small_font.render("饥饿: 后勤产出减半", True, ORANGE), (20, 150))
        
        lc = sum(1 for army in ra if isinstance(army, Logistics))
        screen.blit(small_font.render(f"后勤兵: {lc} (+{lc*5}/1.67s)", True, GRAY), (20, 190))
        
        pygame.draw.rect(screen, (50,50,50), (20, 230, 180, 300), border_radius=5)
        screen.blit(small_font.render("兵种选择", True, WHITE), (30, 235))

        for i in range(7):
            y_pos = 270 + i*40
            if i == cui:
                pygame.draw.rect(screen, (100,100,100), (25, y_pos, 170, 35), border_radius=3)
            pygame.draw.circle(screen, unit_colors[i], (40, y_pos+17), 10)
            screen.blit(tiny_font.render(f"{i+1}. {unit_names[i]} ({unit_types[i](0,0).cost})", True, WHITE), (60, y_pos+7))

        screen.blit(small_font.render("点击格子放置单位 | 按 ESC 返回", True, WHITE), (20, SCREEN_HEIGHT-40))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                if event.key == pygame.K_1: cui = 0
                if event.key == pygame.K_2: cui = 1
                if event.key == pygame.K_3: cui = 2
                if event.key == pygame.K_4: cui = 3
                if event.key == pygame.K_5: cui = 4
                if event.key == pygame.K_6: cui = 5
                if event.key == pygame.K_7: cui = 6
            
            if not game_over and not game_victory and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_x, mouse_y = event.pos
                
                for army in ra:
                    if isinstance(army, Shieldman):
                        if abs(mouse_x - army.x) < 25 and abs(mouse_y - army.y) < 25:
                            army.heal_self()
                            break
                
                col = (mouse_x - OFFSET_X_GRASS) // CELL_WIDTH_GRASS
                row = (mouse_y - OFFSET_Y_GRASS) // CELL_HEIGHT_GRASS

                if 0<=col<COLS_GRASS and 0<=row<ROWS_GRASS and (row,col) not in oc:
                    unit = unit_types[cui](row, col)
                    unit.x = OFFSET_X_GRASS + col * CELL_WIDTH_GRASS + CELL_WIDTH_GRASS // 2
                    unit.y = OFFSET_Y_GRASS + row * CELL_HEIGHT_GRASS + CELL_HEIGHT_GRASS // 2
                    unit.rect.x = unit.x - 20
                    unit.rect.y = unit.y - 25
                    unit.row = row
                    unit.col = col
                    if game_state["resources"] >= unit.cost:
                        ra.append(unit)
                        oc.add((row, col))
                        game_state["resources"] -= unit.cost
            
            if game_over or game_victory:
                if restart_btn.is_clicked(event):
                    game_state.update({"resources":150, "score":0, "wave":1, "level":3})
                    battle_grassland()
                    running = False
                if menu_btn.is_clicked(event):
                    running = False
        
        if not game_over and not game_victory:
            wave = game_state["wave"]
            if wave <= MW:
                est += 1
                if est >= esi:
                    est = 0
                    spawn_row = random.choice(range(ROWS_GRASS))

                    if wave <= 2:
                        es.append(Enemy(spawn_row))
                    elif wave <= 4:
                        r = random.random()
                        if r < 0.6:
                            es.append(Enemy(spawn_row))
                        elif r < 0.85:
                            es.append(FastEnemy(spawn_row))
                        else:
                            es.append(BomberEnemy(spawn_row))
                    elif wave <= 7:
                        r = random.random()
                        if r < 0.4:
                            es.append(Enemy(spawn_row))
                        elif r < 0.6:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.75:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.85:
                            es.append(BomberEnemy(spawn_row))
                        else:
                            es.append(ArcherEnemy(spawn_row))
                    elif wave <= 10:
                        r = random.random()
                        if r < 0.25:
                            es.append(Enemy(spawn_row))
                        elif r < 0.4:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.55:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.65:
                            es.append(BomberEnemy(spawn_row))
                        elif r < 0.8:
                            es.append(ArcherEnemy(spawn_row))
                        elif r < 0.9:
                            es.append(OfficerEnemy(spawn_row))
                        else:
                            es.append(GeneralEnemy(spawn_row))
                    else:
                        r = random.random()
                        if r < 0.15:
                            es.append(Enemy(spawn_row))
                        elif r < 0.25:
                            es.append(FastEnemy(spawn_row))
                        elif r < 0.4:
                            es.append(HeavyEnemy(spawn_row))
                        elif r < 0.5:
                            es.append(BomberEnemy(spawn_row))
                        elif r < 0.65:
                            es.append(ArcherEnemy(spawn_row))
                        elif r < 0.8:
                            es.append(OfficerEnemy(spawn_row))
                        else:
                            es.append(GeneralEnemy(spawn_row))

                    es[-1].x = OFFSET_X_GRASS + COLS_GRASS * CELL_WIDTH_GRASS + 20
                    es[-1].y = OFFSET_Y_GRASS + spawn_row * CELL_HEIGHT_GRASS + CELL_HEIGHT_GRASS // 2
                    es[-1].rect.x = es[-1].x - 20
                    es[-1].rect.y = es[-1].y - 25

                    esd += 1

                    if esd >= wave * epw:
                        game_state["wave"] += 1
                        esi = max(60, esi - 5)

            if game_state["wave"] > MW and len(es) == 0:
                game_victory = True
            
            rt += 1
            if rt >= ri:
                rt = 0
                game_state["resources"] += lc * 5
            
            for army in ra[:]:
                army.update()
                
                if isinstance(army, Sniper):
                    target = None
                    min_distance = float('inf')
                    for enemy in es:
                        if enemy.x > army.x:
                            distance = army.get_distance(enemy)
                            if distance < min_distance:
                                min_distance = distance
                                target = enemy
                    army.target = target
                    if army.attack_cooldown == 0:
                        if target:
                            target.take_damage(army.damage)
                            army.attack_cooldown = army.attack_interval
                            army.attack_animation_timer = army.attack_animation_duration
                elif isinstance(army, Artillery):
                    if army.attack_cooldown == 0:
                        target = None
                        max_x = 0
                        for enemy in es:
                            if abs(enemy.y - army.y) < 30 and enemy.x > army.x and enemy.x > max_x:
                                max_x = enemy.x
                                target = enemy
                        if target:
                            art_bs.append(ArtilleryBullet(army.x+25, army.y, target.x, target.y, army.damage))
                            army.attack_cooldown = army.attack_interval
                            army.attack_animation_timer = army.attack_animation_duration
                elif isinstance(army, Medic):
                    if army.heal_cooldown == 0:
                        target = None
                        min_hp_ratio = 1.0
                        for a in ra:
                            if a != army and abs(a.y - army.y) < 30 and a.hp < a.max_hp:
                                hp_ratio = a.hp / a.max_hp
                                if hp_ratio < min_hp_ratio:
                                    min_hp_ratio = hp_ratio
                                    target = a
                        if target:
                            target.hp = min(target.max_hp, target.hp + army.heal_amount)
                            army.heal_cooldown = army.heal_interval
                            army.heal_animation_timer = 15
                else:
                    if army.attack_cooldown == 0:
                        target = None
                        min_distance = float('inf')
                        for enemy in es:
                            if abs(enemy.y - army.y) < 30 and enemy.x > army.x:
                                distance = army.get_distance(enemy)
                                if distance < army.attack_range and distance < min_distance:
                                    min_distance = distance
                                    target = enemy
                        if target:
                            target.take_damage(army.damage)
                            army.attack_cooldown = army.attack_interval
                            army.attack_animation_timer = army.attack_animation_duration

                if army.hp <= 0:
                    ra.remove(army)
                    oc.remove((army.row, army.col))

            for ab in art_bs[:]:
                if ab.update() == False:
                    if ab.explosion_timer > 0:
                        for enemy in es[:]:
                            if abs(enemy.x - ab.target_x) < 50 and abs(enemy.y - ab.target_y) < 50:
                                if enemy.take_damage(ab.damage):
                                    es.remove(enemy)
                                    game_state["score"] += 10
                                    game_state["resources"] += 15
                    art_bs.remove(ab)
            
            for bullet in bs[:]:
                bullet.update()
                if bullet.x > SCREEN_WIDTH:
                    bs.remove(bullet)
                    continue
                for enemy in es[:]:
                    if bullet.rect.colliderect(enemy.rect):
                        enemy.take_damage(bullet.damage)
                        bs.remove(bullet)
                        break
            
            for enemy in es[:]:
                can_move = True
                for army in ra:
                    if abs(enemy.y - army.y) < 30:
                        army_left = army.x - 20
                        army_right = army.x + 20
                        next_x = enemy.x - enemy.speed
                        enemy_left = next_x - 20
                        enemy_right = next_x + 20
                        if enemy_right > army_left and enemy_left < army_right:
                            can_move = False
                            break
                
                if can_move:
                    enemy.x -= enemy.speed
                    enemy.rect.x = enemy.x - 20
                
                enemy.attack_animation_timer = max(0, enemy.attack_animation_timer - 1)
                
                if enemy.attack_cooldown == 0:
                    for army in ra:
                        if abs(enemy.y - army.y) < 30 and enemy.get_distance(army) < enemy.attack_range:
                            army.take_damage(enemy.damage)
                            enemy.attack_cooldown = enemy.attack_interval
                            enemy.attack_animation_timer = enemy.attack_animation_duration
                            break
                
                enemy.attack_cooldown = max(0, enemy.attack_cooldown - 1)
                
                if enemy.x < OFFSET_X_GRASS:
                    game_over = True
                
                if enemy.hp <= 0:
                    es.remove(enemy)
                    game_state["score"] += 10
                    game_state["resources"] += 15
        
        for army in ra:
            army.draw(screen)
        for bullet in bs:
            bullet.draw(screen)
        for ab in art_bs:
            ab.draw(screen)
        for enemy in es:
            enemy.draw(screen)
        
        for army in ra:
            if isinstance(army, Swordsman) and army.attack_animation_timer > 0:
                alpha = int(255 * (army.attack_animation_timer / army.attack_animation_duration))
                arc_surf = pygame.Surface((60, 60), pygame.SRCALPHA)
                pygame.draw.arc(arc_surf, (0, 255, 0, alpha), (5, 5, 50, 50), -0.5, 0.5, 5)
                screen.blit(arc_surf, (army.x, army.y - 30))
        
        for army in ra:
            if isinstance(army, Sniper) and army.target and army.target.hp > 0:
                pygame.draw.circle(screen, (255, 0, 0), (int(army.target.x), int(army.target.y)), 15, 4)
                pygame.draw.circle(screen, (255, 100, 100), (int(army.target.x), int(army.target.y)), 8)
                pygame.draw.line(screen, (255, 0, 0), (int(army.target.x)-20, int(army.target.y)), (int(army.target.x)+20, int(army.target.y)), 2)
                pygame.draw.line(screen, (255, 0, 0), (int(army.target.x), int(army.target.y)-20), (int(army.target.x), int(army.target.y)+20), 2)
        
        if game_over:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill(OVERLAY_COLOR)
            screen.blit(overlay, (0, 0))
            
            over_title = title_font.render("游戏失败", True, RED)
            screen.blit(over_title, over_title.get_rect(center=(SCREEN_WIDTH//2, 200)))
            
            screen.blit(small_font.render(f"最终波次: {game_state['wave']}", True, WHITE), (SCREEN_WIDTH//2-80, 300))
            screen.blit(small_font.render(f"最终得分: {game_state['score']}", True, WHITE), (SCREEN_WIDTH//2-80, 340))
            
            restart_btn.draw(screen)
            menu_btn.draw(screen)
        
        if game_victory:
            game_state["completed_levels"].add(3)
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 50, 0, 180))
            screen.blit(overlay, (0, 0))
            
            if len(game_state["completed_levels"]) >= 3:
                victory_title = title_font.render("我们到延安了!", True, YELLOW)
                screen.blit(victory_title, victory_title.get_rect(center=(SCREEN_WIDTH//2, 120)))
                
                victory_subtitle = button_font.render("我们赢了!", True, RED)
                screen.blit(victory_subtitle, victory_subtitle.get_rect(center=(SCREEN_WIDTH//2, 220)))
                
                victory_msg = small_font.render("长征胜利完成!", True, GREEN)
                screen.blit(victory_msg, victory_msg.get_rect(center=(SCREEN_WIDTH//2, 280)))
            else:
                victory_title = title_font.render("胜利!", True, YELLOW)
                screen.blit(victory_title, victory_title.get_rect(center=(SCREEN_WIDTH//2, 150)))
                
                victory_subtitle = button_font.render("过草地胜利完成!", True, GREEN)
                screen.blit(victory_subtitle, victory_subtitle.get_rect(center=(SCREEN_WIDTH//2, 250)))
            
            screen.blit(small_font.render(f"最终波次: {MW}/{MW}", True, WHITE), (SCREEN_WIDTH//2-80, 320))
            screen.blit(small_font.render(f"最终得分: {game_state['score']}", True, WHITE), (SCREEN_WIDTH//2-80, 360))
            screen.blit(small_font.render(f"剩余资源: {game_state['resources']}", True, WHITE), (SCREEN_WIDTH//2-80, 400))
            
            restart_btn.draw(screen)
            menu_btn.draw(screen)
        
        pygame.display.flip()
        clock.tick(60)

def level_select():
    running = True
    while running:
        if main_bg:
            screen.blit(main_bg, (0, 0))
        else:
            screen.fill(BG_COLOR)

        screen.blit(title_text, title_rect)
        
        level1_btn = Button("第一关：血战湘江", BLUE, LIGHT_BLUE, SCREEN_WIDTH//2 - 200, 220, 400, 70)
        level2_btn = Button("第二关：翻雪山", BLUE, LIGHT_BLUE, SCREEN_WIDTH//2 - 200, 320, 400, 70)
        level3_btn = Button("第三关：过草地", BLUE, LIGHT_BLUE, SCREEN_WIDTH//2 - 200, 420, 400, 70)
        back_btn = Button("返回", GRAY, (150,150,150), SCREEN_WIDTH//2 - 200, 520, 400, 70)
        
        level1_btn.draw(screen)
        level2_btn.draw(screen)
        level3_btn.draw(screen)
        back_btn.draw(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if level1_btn.is_clicked(event):
                game_state.update({"resources":150, "score":0, "wave":1, "level":1})
                battle_xiangjiang()
                running = False
            if level2_btn.is_clicked(event):
                game_state.update({"resources":150, "score":0, "wave":1, "level":2})
                battle_snow_mountain()
                running = False
            if level3_btn.is_clicked(event):
                game_state.update({"resources":150, "score":0, "wave":1, "level":3})
                battle_grassland()
                running = False
            if back_btn.is_clicked(event):
                running = False

        pygame.display.flip()

def main_menu():
    running = True
    while running:
        if main_bg:
            screen.blit(main_bg, (0, 0))
        else:
            screen.fill(BG_COLOR)

        screen.blit(title_text, title_rect)
        start_btn.draw(screen)
        quit_btn.draw(screen)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if start_btn.is_clicked(event):
                level_select()
            if quit_btn.is_clicked(event):
                running = False

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main_menu()
